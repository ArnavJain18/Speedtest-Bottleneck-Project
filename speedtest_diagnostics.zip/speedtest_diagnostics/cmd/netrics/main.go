package main

import (
	"io"
	"log"
	"time"

	"github.com/spf13/pflag"
	"github.com/staveesh/speedtest_diagnostics/internal/archive"
	"github.com/staveesh/speedtest_diagnostics/internal/channel"
	"github.com/staveesh/speedtest_diagnostics/internal/config"
	"github.com/staveesh/speedtest_diagnostics/internal/meta"
	"github.com/staveesh/speedtest_diagnostics/internal/network"
	"github.com/staveesh/speedtest_diagnostics/internal/ping"
)

func main() {
	// Define args
	config.Define()
	pflag.CommandLine.MarkHidden("archive")

	// Disable logs
	log.SetOutput(io.Discard)

	// Parse args
	config.Parse()

	// Init metadata
	meta.Init()

	// Start background packet capture
	go network.CaptureProcess()

	// Start speedtest client
	go network.SpeedtestProcess()

	// Start pings to server
	go ping.PingProcess()

	// Wait until speedtest is complete
	<-channel.SpeedtestDone

	// Wait for relaxed state data
	time.Sleep(time.Duration(config.IdleTime) * time.Second)

	// Stop all processes
	close(channel.Stop)
	<-channel.PingDone
	<-channel.CaptureDone

	// Collect metadata
	meta.Collect()

	// Write metadata
	meta.Write()

	// Create tar
	archive.Print()
}
