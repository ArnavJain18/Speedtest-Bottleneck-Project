package network

import (
	"io"
	"log"
	"os/exec"

	"github.com/staveesh/speedtest_diagnostics/internal/channel"
	"github.com/staveesh/speedtest_diagnostics/internal/config"
	"github.com/staveesh/speedtest_diagnostics/internal/meta"
	"github.com/staveesh/speedtest_diagnostics/internal/util"
)

var logParserDone = make(channel.Type)

// Wrapper functions for synchronization
func SpeedtestProcess() {
	defer close(channel.SpeedtestDone)

	// Create a pipe to capture stdout
	logIn, logOut := io.Pipe()
	defer logOut.Close()

	cmd := exec.Command("ndt7-client", "-format", "json")
	logParser := logParserNdt7
	if config.Tool == "ookla" {
		cmd = exec.Command(
			"speedtest",
			"--accept-license",
			"-f", "json",
			"-p", "yes",
		)
		logParser = logParserOokla
	}
	cmd.Stdout = logOut

	meta.MMeta.SpeedtestStartTime = util.GetTime()
	if err := cmd.Start(); err != nil {
		log.Println("[speedtest] client error:", err)
		return
	}
	log.Println("[speedtest] started")

	go logParser(logIn)
	log.Println("[speedtest] [log parser] started")

	if err := cmd.Wait(); err != nil {
		log.Println("[speedtest] client error:", err)
		return
	}
	meta.MMeta.SpeedtestEndTime = util.GetTime()
	log.Println("[speedtest] complete")

	<-logParserDone
	log.Println("[speedtest] [log parser] complete")
}
