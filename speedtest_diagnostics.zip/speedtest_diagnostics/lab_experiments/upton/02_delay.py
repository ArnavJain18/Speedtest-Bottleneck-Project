import os
import subprocess
from pathlib import Path
from tqdm import tqdm

bw = 50
latency_vals = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
loss = 0
tools = ["ndt"]
interfaces = ["lan1", "eth2"] # lan3 is download (hop1), eth2 is upload (hop 2)
router_username = "root"
router_hostname = "192.168.1.1"
shaper_script = "bw_lat_loss.sh"
data_root = "../../data/delay"
num_reps_per_config = 20

binary_path = "../../bin/bottleneck-finder"

def ssh_command(cmd):
    result = subprocess.run(
        ["ssh", "-i", "~/.ssh/id_rsa_upton", f"{router_username}@{router_hostname}", cmd],
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE,
        text = True
    )
    print("############### Output #####################")
    print(result.stdout)
    print("############### Errors #####################")
    print(result.stderr)
    print("############################################")

def start_shaping(iface, bw, lat, loss):
    bw *= 1000 # mbps to kbps
    cmd = f"/root/{shaper_script} start {iface} {bw} {lat} {loss}"
    print(cmd)
    ssh_command(cmd)

def stop_shaping(iface):
    cmd = f"/root/{shaper_script} stop {iface}"
    print(cmd)
    ssh_command(cmd)

def go(resume_index=0):
    runs = []
    for iface in interfaces:
        for speedtest_tool in tools:
            for lat in latency_vals:
                for rep in range(num_reps_per_config):
                    runs.append((iface, speedtest_tool, lat, rep))

    trimmed_runs = runs[resume_index:]
    for iface, speedtest_tool, lat, rep in tqdm(trimmed_runs):
        print(f"##################### Run #{resume_index} Starting ########################")
        start_shaping(iface, bw, lat, loss)

        output_dir = f"{data_root}/{iface}/{speedtest_tool}/LAT={lat}"
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        run_tool(speedtest_tool, output_dir)

        stop_shaping(iface)
        print(f"##################### Run #{resume_index} Ending ########################")
        resume_index += 1

def run_tool(speedtest_tool, output_dir):
    result = subprocess.run(
        [binary_path, "-t", speedtest_tool, "-o", output_dir, "-a"],
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE,
        text = True
    )
    print("############### Output #####################")
    print(result.stdout)
    print("############### Errors #####################")
    print(result.stderr)
    print("############################################")

if __name__ == '__main__':
    go()