import os
import subprocess
from pathlib import Path
from tqdm import tqdm
import time

bw_vals_mbps = [1, 5, 10, 25, 50, 75, 100, 200, 300, 400, 500]
latency = 1
jitter = 0
tools = ["ndt"]
interfaces = ["eth2", "lan1"] # lan3 is download (hop 1), eth2 is upload (hop 2)
router_username = "root"
router_hostname = "192.168.1.1"
shaper_script = "bw_lat_jitter.sh"
data_root = "../../data/throughput"
num_reps_per_config = 20

binary_path = "../../bin/bottleneck-finder"

def ssh_command(cmd):
    result = subprocess.run(
        ["ssh", "-i", "~/.ssh/id_rsa_upton", f"{router_username}@{router_hostname}", cmd],
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE,
        text = True
    )
    print("############### Output #####################")
    print(result.stdout)
    print("############### Errors #####################")
    print(result.stderr)
    print("############################################")

def start_shaping(iface, bw, lat, jit):
    bw *= 1000 # mbps to kbps
    cmd = f"/root/{shaper_script} start {iface} {bw} {lat} {jit}"
    print(cmd)
    ssh_command(cmd)

def stop_shaping(iface):
    cmd = f"/root/{shaper_script} stop {iface}"
    print(cmd)
    ssh_command(cmd)

def go(resume_index=0):
    runs = []
    for iface in interfaces:
        for speedtest_tool in tools:
            for bw in bw_vals_mbps:
                for rep in range(num_reps_per_config):
                    runs.append((iface, speedtest_tool, bw, rep))

    trimmed_runs = runs[resume_index:]
    for iface, speedtest_tool, bw, rep in tqdm(trimmed_runs):
        print(f"##################### Run #{resume_index} Starting ########################")
        start_shaping(iface, bw, latency, jitter)

        output_dir = f"{data_root}/{iface}/{speedtest_tool}/BW={bw}"
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        run_tool(speedtest_tool, output_dir)

        stop_shaping(iface)
        print(f"##################### Run #{resume_index} Ending ########################")
        resume_index += 1

        time.sleep(5)

def run_tool(speedtest_tool, output_dir):
    result = subprocess.run(
        [binary_path, "-t", speedtest_tool, "-o", output_dir, "-a"],
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE,
        text = True
    )
    print("############### Output #####################")
    print(result.stdout)
    print("############### Errors #####################")
    print(result.stderr)
    print("############################################")

if __name__ == '__main__':
    go()