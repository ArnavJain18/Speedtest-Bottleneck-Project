#!/bin/bash

CMD=$1
IFACE=$2
BW=$3
LATENCY=$4
LOSS=$5

TC=tc

start() {
    if [ ! "$BW" ]; then
        echo "BW is empty!"
        exit
    fi

    $TC qdisc add dev $IFACE root handle 1: htb default 11
    $TC class add dev $IFACE parent 1: classid 1:11 htb rate ${BW}kbit

    $TC qdisc add dev $IFACE parent 1:11 handle 10: netem delay ${LATENCY}ms loss ${LOSS}%
}

stop() {
    # Stop the bandwidth shaping.
    $TC qdisc del dev $IFACE root
}

stop_all() {
    $TC qdisc del dev $IFACE root
}

update() {
    # Replace the existing qdisc with new settings for rate, delay, jitter, and loss.
    $TC qdisc replace dev $IFACE root handle 1: htb default 11
    $TC class replace dev $IFACE parent 1: classid 1:11 htb rate ${BW}kbit
    $TC qdisc replace dev $IFACE parent 1:11 handle 10: netem delay ${LATENCY}ms loss ${LOSS}%
}

show() {
    $TC -s qdisc ls dev $IFACE
    $TC class show dev $IFACE
    $TC filter show dev $IFACE
}

case "$CMD" in
    start)
        echo -n "Starting bandwidth shaping: "
        start
        echo "done"
        ;;
    stop)
        echo -n "Stopping bandwidth shaping: "
        stop
        echo "done"
        ;;
    update)
        echo -n "Updating bandwidth shaping at $BW: "
        update
        echo "done"
        ;;
    show)
        echo "Bandwidth shaping status for $IFACE:"
        show
        echo ""
        ;;
    *)
        echo "Usage: $0 <start|show|update|stop> <iface> <bw> <latency> <loss>"
        ;;
esac

exit 0
