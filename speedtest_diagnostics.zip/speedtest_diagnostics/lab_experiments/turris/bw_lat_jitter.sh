# Place this script at /root of the router

CMD=$1
IFACE=$2
BW=$3
LATENCY=$4
JITTER=$5

# Name of the traffic control command.
TC=tc

start() {

if [ ! "$BW" ]
then
  echo "BW is empty!"
  exit
fi

$TC qdisc add dev $IFACE root handle 1: htb default 11
$TC class add dev $IFACE parent 1: classid 1:11 htb rate ${BW}kbit
$TC qdisc add dev $IFACE parent 1:11 handle 10: netem delay ${LATENCY}ms ${JITTER}ms

}

stop() {

  # Stop the bandwidth shaping.
  $TC qdisc del dev $IFACE root

}

stop_all() {

    $TC qdisc del dev $IFACE root
    
}

update() {
    $TC qdisc replace dev $IFACE root handle 1: htb default 11
    $TC class replace dev $IFACE parent 1: classid 1:11 htb rate ${BW}kbit
    $TC qdisc replace dev $IFACE parent 1:11 handle 10: netem delay ${LATENCY}ms ${JITTER}ms
}


show() {

    $TC -s qdisc ls dev $IFACE
    $TC class show dev $IFACE
    $TC filter show dev $IFACE

}

case "$CMD" in

  start)

    echo -n "Starting bandwidth shaping: "
    start
    echo "done"
    ;;

  stop)

    echo -n "Stopping bandwidth shaping: "
    stop
    echo "done"
    ;;

  update)

    echo -n "Updating bandwidth shaping at $BW: "
    update
    echo "done"
    ;;

  show)

    echo "Bandwidth shaping status for $IFACE:"
    show
    echo ""
    ;;

  *)

    pwd=$(pwd)
    echo "shaper.sh <start|show|update|stop> <iface> <bw> <latency> <jitter>"
    ;;

esac

exit 0

